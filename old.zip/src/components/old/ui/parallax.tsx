import React from "react";

type ParallaxSectionProps = {
	backgroundImage: string;
	children: React.ReactNode;
	className?: string; // optional for customizing foreground styles
};

const ParallaxSection: React.FC<ParallaxSectionProps> = ({
	backgroundImage,
	children,
	className = "",
}) => {
	return (
		<div className="relative h-screen overflow-hidden">
			{/* Background Layer */}
			<div
				className="absolute top-0 left-0 w-full h-screen bg-cover bg-center"
				style={{
					backgroundImage: `url(${backgroundImage})`,
					transform: "translateZ(0) scale(1.5)",
				}}
			></div>

			{/* Foreground Content */}
			<div
				className={`relative z-10 flex items-center justify-center h-full ${className}`}
			>
				{children}
			</div>
		</div>
	);
};

export default ParallaxSection;
