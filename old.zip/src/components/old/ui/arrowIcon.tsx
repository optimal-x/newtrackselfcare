const ArrowIcon = ({ className }: { className?: string }) => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="currentColor"
        className={`w-6 h-6 ${className}`}
    >
        <title id="upArrowTitle">Upward arrow icon</title>
        <path d="M12 4.75a.75.75 0 0 1 .53.22l7 7a.75.75 0 1 1-1.06 1.06L12.75 6.81v11.44a.75.75 0 0 1-1.5 0V6.81L5.53 13.03a.75.75 0 1 1-1.06-1.06l7-7a.75.75 0 0 1 .53-.22z" />
    </svg>
);

export default ArrowIcon;
