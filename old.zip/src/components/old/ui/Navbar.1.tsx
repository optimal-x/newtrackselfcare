import { useState } from "react";

export const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="bg-white shadow-md">
            <div className="container mx-auto flex justify-between items-center p-4">
                <div className="text-blue-500 font-bold text-xl">
                    <img
                        className="h-15 w-auto object-contain"
                        src="../assets/newtrack_logo_green.svg"
                        alt="serene and inviting space with soft lighting, comfortable seating, and subtle natural elements, representing a sanctuary for mental wellness"
                    />
                </div>
                <button
                    type="button"
                    onClick={() => setIsOpen(!isOpen)}
                    className="lg:hidden text-(--kombu-green)"
                    aria-label="Toggle menu"
                >
                    <div className="w-6 h-6 relative">
                        {!isOpen ? (
                            <svg
                                className="w-6 h-6"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M4 6h16M4 12h16M4 18h16"
                                />
                            </svg>
                        ) : (
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                strokeWidth={1.5}
                                stroke="currentColor"
                                className="w-6 h-6"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M6 18L18 6M6 6l12 12"
                                />
                            </svg>
                        )}
                    </div>
                </button>
                <div className="hidden lg:flex">
                    <ul className="lg:flex space-x-4">
                        <li>
                            <a className="text-(--kombu-green)" href="#home">
                                Home
                            </a>
                        </li>
                        <li>
                            <a
                                className="text-(--kombu-green)"
                                href="#services"
                            >
                                Services
                            </a>
                        </li>
                        <li>
                            <a className="text-(--kombu-green)" href="#contact">
                                Contact
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div
                className={`lg:hidden transition-all duration-300 ease-in-out ${
                    isOpen
                        ? "translate-y-0 opacity-100"
                        : "translate-y-[-10px] opacity-0 h-0 overflow-hidden"
                }`}
            >
                <ul className="bg-white p-4">
                    <li>
                        <a
                            className="text-(--kombu-green) block py-2"
                            href="#home"
                        >
                            Home
                        </a>
                    </li>
                    <li>
                        <a
                            className="text-(--kombu-green) block py-2"
                            href="#services"
                        >
                            Services
                        </a>
                    </li>
                    <li>
                        <a
                            className="text-(--kombu-green) py-2"
                            href="#contact"
                        >
                            Contact
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    );
};