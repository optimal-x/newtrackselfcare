import { useEffect, useState } from "react";
import ArrowIcon from "./arrowIcon";

const ScrollToTop: React.FC = () => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        const toggleVisibility = () => {
            setVisible(window.scrollY > 300);
        };

        window.addEventListener("scroll", toggleVisibility);
        return () => window.removeEventListener("scroll", toggleVisibility);
    }, []);

    const scrollToTop = () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    return (
        <button
            type="button"
            onClick={scrollToTop}
            className={`fixed bottom-6 right-6 z-50 p-3 rounded-full bg-(--black) text-(--old-lace) shadow-md transition-opacity ${
                visible || "hidden"
            }`}
            aria-label="Scroll to top"
        >
            {/* Up Arrow SVG */}
            <ArrowIcon className="stroke-[--old-lace]" />
        </button>
    );
};

export default ScrollToTop;
