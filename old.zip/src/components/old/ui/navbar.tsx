// components/Navbar.tsx
import { useState } from "react";
import { FiMenu, FiX } from "react-icons/fi"; // Optional: install react-icons
import NEWTRACK_LOGO from "../../assets/newtrack-logo-green.svg";

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);

    const toggleMenu = () => setIsOpen((prev) => !prev);

    return (
        <nav
            className="w-full top-0 left-0 z-50 bg-opacity-80 backdrop-blur-md shadow-sm"
            aria-label="Main navigation"
        >
            <div className="max-w-7xl mx-auto px-4 lg:px-6 py-4 flex justify-between items-center">
                {/* Logo */}
                <a href="#home" aria-label="Go to homepage">
                    <img
                        className="h-12 w-auto object-contain"
                        src={NEWTRACK_LOGO}
                        alt="NewTrack logo representing a sanctuary for mental wellness"
                    />
                </a>

                {/* Desktop Nav */}
                <ul className="hidden lg:flex space-x-6 font-medium text-black font-bold">
                    <li>
                        <a
                            href="#home"
                            className="text-xl hover:text-(--kombu-green) transition-colors font-[Playfair] font-bold"
                        >
                            Home
                        </a>
                    </li>
                    <li>
                        <a
                            href="#services"
                            className="text-xl hover:text-(--kombu-green) transition-colors font-[Playfair] font-bold"
                        >
                            Services
                        </a>
                    </li>
                    <li>
                        <a
                            href="#contact"
                            className="text-xl hover:text-(--kombu-green) transition-colors font-[Playfair] font-bold"
                        >
                            Contact
                        </a>
                    </li>
                </ul>

                {/* Mobile Toggle */}
                <button
                    type="button"
                    onClick={toggleMenu}
                    className="lg:hidden text-3xl text-(--kombu-green) focus:outline-none"
                    aria-label={isOpen ? "Close menu" : "Open menu"}
                    aria-expanded={isOpen}
                >
                    {isOpen ? <FiX /> : <FiMenu />}
                </button>
            </div>

            {/* Mobile Menu */}
            {isOpen && (
                <ul className="lg:hidden px-4 pb-4 space-y-4 font-medium text-black font-bold">
                    <li>
                        <a
                            href="#home"
                            className="block text-xl hover:text-(--kombu-green) transition-colors font-[Playfair] font-bold"
                        >
                            Home
                        </a>
                    </li>
                    <li>
                        <a
                            href="#services"
                            className="block text-xl hover:text-(--kombu-green) transition-colors font-[Playfair] font-bold"
                        >
                            Services
                        </a>
                    </li>
                    <li>
                        <a
                            href="#contact"
                            className="block text-xl hover:text-(--kombu-green) transition-colors font-[Playfair] font-bold"
                        >
                            Contact
                        </a>
                    </li>
                </ul>
            )}
        </nav>
    );
};

export default Navbar;