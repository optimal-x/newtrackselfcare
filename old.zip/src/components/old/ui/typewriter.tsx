"use client";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type TypewriterProps = {
    words: string[];
    typeSpeed?: number;
    deleteSpeed?: number;
    pauseTime?: number;
    loop?: boolean;
    className?: string;
};

export const Typewriter = ({
    words,
    typeSpeed = 50,
    deleteSpeed = 30,
    pauseTime = 2000,
    className,
}: TypewriterProps) => {
    const [displayedText, setDisplayedText] = useState("");
    const [wordIndex, setWordIndex] = useState(0);
    const [isDeleting, setIsDeleting] = useState(false);

    const timeoutRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        const currentWord = words[wordIndex % words.length];

        if (isDeleting) {
            // Deleting text
            if (displayedText.length > 0) {
                timeoutRef.current = setTimeout(() => {
                    setDisplayedText(
                        currentWord.slice(0, displayedText.length - 1),
                    );
                }, deleteSpeed);
            } else {
                setIsDeleting(false);
                setWordIndex((prev) => (prev + 1) % words.length);
            }
        } else {
            // Typing text
            if (displayedText.length < currentWord.length) {
                timeoutRef.current = setTimeout(() => {
                    setDisplayedText(
                        currentWord.slice(0, displayedText.length + 1),
                    );
                }, typeSpeed);
            } else {
                // Done typing, wait then delete
                timeoutRef.current = setTimeout(() => {
                    setIsDeleting(true);
                }, pauseTime);
            }
        }

        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, [
        displayedText,
        isDeleting,
        wordIndex,
        words,
        typeSpeed,
        deleteSpeed,
        pauseTime,
    ]);

    return (
        <span className={cn("whitespace-pre", className)}>
            {displayedText}
            <span className="animate-pulse">|</span>
        </span>
    );
};
