const JaneAppFrame = () => (
    <section
        className="md:px-15 md:py-8 lg:px-30 lg:py-15 p-4 bg-(--old-lace)"
        aria-label="Booking System Form"
    >
        <h3 className=" lg:text-6xl text-2xl text-center p-4">Book With Us</h3>
        {/* JaneApp Booking Iframe */}
        <iframe
            src="https://yourclinicname.janeapp.com"
            title="Book an Appointment"
            className="w-full h-[600px] rounded-lg border"
            loading="lazy"
        ></iframe>
    </section>
);

export default JaneAppFrame;
