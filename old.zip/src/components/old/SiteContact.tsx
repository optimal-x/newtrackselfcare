const Contact: React.FC = () => (
    <section id="contact" aria-label="Contact Section Content">
        <div></div>
    </section>
);

export default Contact;
