import YOGA_IMG from "../assets/page-5-rhs.webp";

const MindfulMovementAndMeditation: React.FC = () => {
    return (
        <section
            id="mindful-movement-and-meditation"
            className="bg-[var(--old-lace)] mx-4 my-4 px-2 py-2 md:m-10 md:p-5 lg:m-20 lg:p-10"
            aria-label="Mindful Movement and Meditation"
        >
            <h3 className="text-left pb-10 text-3xl lg:text-6xl text-(--kombu-green) font-[Playfair]">
                Mindful Movement & Meditation: Classes for All
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <article
                    className="p-6 rounded-lg lg:text-2xl"
                    aria-label="Class Description"
                >
                    <p>
                        Our in-clinic yoga studio offers a variety of classes
                        designed for all levels of practice, from beginners to
                        advanced practitioners. Embrace mindful movement and
                        meditation to enhance your physical and mental
                        well-being.
                    </p>
                    <br />
                    <p>
                        Classes focus on breathwork, gentle stretches, and
                        guided meditation to reduce stress, improve focus, and
                        cultivate inner calm.
                    </p>
                </article>

                <div className="p-6 rounded-lg shadow">
                    <img
                        src={YOGA_IMG}
                        className="h-auto xl:lg:w-400 object-contain rounded-lg"
                        alt="Yoga session in clinic space"
                    />
                </div>
            </div>
        </section>
    );
};

export default MindfulMovementAndMeditation;