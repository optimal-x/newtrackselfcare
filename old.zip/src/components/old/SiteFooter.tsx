const Footer: React.FC = () => (
    <footer className="bg-[var(--kombu-green)] text-[var(--old-lace)] px-6 py-10 md:px-15 lg:px-30">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
            {/* Left Column */}
            <div>
                <h4 className="text-2xl font-[Playfair] mb-4">NewTrack</h4>
                <p className="text-lg">
                    Empowering holistic well-being through innovative therapies
                    and compassionate care.
                </p>
                <p className="pt-4 text-sm">
                    © {new Date().getFullYear()} NewTrack Selfcare. All rights
                    reserved.
                </p>
            </div>

            {/* Right Column */}
            <div className="flex flex-col lg:items-end">
                <h5 className="text-xl mb-3 font-semibold">Connect</h5>
                <ul className="space-y-2 text-lg">
                    <li>
                        <a href="#psychotherapy" className="hover:underline">
                            Psychotherapy
                        </a>
                    </li>
                    <li>
                        <a
                            href="#psychedelic-assisted-therapy"
                            className="hover:underline"
                        >
                            Psychedelic-Assisted Therapy
                        </a>
                    </li>
                    <li>
                        <a
                            href="#mindful-movement-and-meditation"
                            className="hover:underline"
                        >
                            Mindful Movement & Meditation
                        </a>
                    </li>
                    <li>
                        <a
                            href="#holistic-body-work"
                            className="hover:underline"
                        >
                            Holistic Body Work
                        </a>
                    </li>
                    <li>
                        <a
                            href="#advanced-clinical-services"
                            className="hover:underline"
                        >
                            Advanced Clinical Services
                        </a>
                    </li>
                    <li>
                        <a
                            href="#systemic-change-therapies"
                            className="hover:underline"
                        >
                            Systemic Change Therapies
                        </a>
                    </li>
                    <li>
                        <a
                            href="#workshops-and-group-therapy"
                            className="hover:underline"
                        >
                            Workshops & Group Therapy
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
);

export default Footer;
