import ACUPUNCTURE_THERAPY_SVG from "../assets/acupuncture-24dp.svg";
import SOUND_THERAPY_SVG from "../assets/transcribe-24dp.svg";
import MASSAGE_THERAPY_SVG from "../assets/volunteer-activism-24dp.svg";

type HolisticContentBoxesProps = {
    icon: string;
    alt: string;
    title: string;
    content: string;
};

const HolisticContentBox: React.FC<HolisticContentBoxesProps> = ({
    icon,
    alt,
    title,
    content,
}) => {
    return (
        <article
            className="flex flex-col lg:py-6 text-2xl relative w-full text-(--old-lace)"
            aria-label={title}
        >
            <div className="flex items-start gap-4">
                <img
                    src={icon}
                    alt={alt}
                    className="w-10 h-10 flex-shrink-0 mt-1"
                />
                <div>
                    <h4 className="text-2xl lg:text-3xl font-[Lora] lg:mb-2">
                        {title}
                    </h4>
                    <p className="text-sm lg:text-2xl">{content}</p>
                </div>
            </div>
        </article>
    );
};

const boxes: HolisticContentBoxesProps[] = [
    {
        icon: MASSAGE_THERAPY_SVG,
        alt: "Massage therapy icon",
        title: "Massage Therapy",
        content:
            "Release tension and improve circulation with therapeutic touch.",
    },
    {
        icon: ACUPUNCTURE_THERAPY_SVG,
        alt: "Acupuncture icon",
        title: "Acupuncture",
        content: "Balance your energy and address deep-rooted imbalances.",
    },
    {
        icon: SOUND_THERAPY_SVG,
        alt: "Sound healing icon",
        title: "Sound Healing",
        content: "Restore harmony through vibrations and resonance.",
    },
];

const HolisticBodyWork: React.FC = () => (
    <section
        id="holistic-body-work"
        className="px-4 my-20 md:px-15 lg:px-30 text-(--old-lace)"
        aria-label="Holistic Body Work section"
    >
        <h3 className="text-3xl text-center lg:text-left lg:text-6xl md:pb-5 font-[Playfair]">
            Holistic Body Work: Restore Your Balance
        </h3>

        <div className="flex flex-col lg:flex-row gap-6 bg-(--kombu-green)">
            {boxes.map((box) => (
                <div
                    key={box.title.toLowerCase().replaceAll(" ", "_")}
                    className="w-full lg:w-1/3"
                >
                    <HolisticContentBox {...box} />
                </div>
            ))}
        </div>

        <p className="py-7 text-xl">
            Our body work services complement your mental wellness journey,
            promoting holistic healing and well-being.
        </p>
    </section>
);

export default HolisticBodyWork;