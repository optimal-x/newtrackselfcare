import HOME_BG_IMG from "../assets/home-page.webp";
import Navbar from "./ui/navbar.tsx";
import { Typewriter } from "./ui/typewriter.tsx";

const Home = () => (
    <section
        id="home"
        className="relative w-full bg-fixed bg-center bg-cover "
        style={{ backgroundImage: `url(${HOME_BG_IMG})` }}
        aria-label="Home section with welcome message"
    >
        {/* Overlay */}
        <div className="absolute inset-0 bg-(--old-lace)/70 z-0" />

        {/* Navbar */}
        <Navbar />

        {/* Main Content */}
        <main className="relative z-10 flex flex-col items-center justify-center h-auto lg:px-4 text-center py-16 md:mx-15 lg:px-30">
            <h1 className="px-4  text-5xl lg:text-7xl font-bold font-[Playfair] text-(--kombu-green)">
                Welcome to NewTrack: Your Sanctuary for the
            </h1>

            <div className="mt-4">
                <Typewriter
                    words={["Mind", "Soul"]}
                    typeSpeed={300}
                    deleteSpeed={50}
                    pauseTime={5000}
                    className="text-6xl lg:text-9xl font-[Playfair] text-(--kombu-green)"
                    aria-label="Animated typewriter text cycling through 'Mind' and 'Soul'"
                />
            </div>

            <p className="mt-10 px-7 lg:px-30 font-[Lora] lg:text-2xl text-(--kombu-green)">
                Discover a holistic approach to mental health and wellness.
                We're here to help you achieve your goals and find inner peace.
            </p>
        </main>
    </section>
);

export default Home;