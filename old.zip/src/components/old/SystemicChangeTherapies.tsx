const therapies = [
    {
        title: "Light Therapy",
        description:
            "Utilizing specific light wavelengths to regulate mood, sleep patterns, and energy levels.",
    },
    {
        title: "Sound Therapy",
        description:
            "Harnessing therapeutic sounds and frequencies to promote deep relaxation and mental clarity.",
    },
];

const SystemicChangeTherapies: React.FC = () => (
    <section
        id="systemic-change-therapies"
        className="bg-(--kombu-green)  px-4 py-10 md:p-15 lg:p-30"
        aria-label="Systemic Change Therapies"
    >
        <h3 className="text-(--old-lace) font-[Playfair] text-3xl pb-3 lg:text-4xl lg:text-6xl lg:pb-7 text-center lg:text-left">
            Systemic Change Therapies
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {therapies.map(({ title, description }) => (
                <article
                    key={title.toLowerCase().replaceAll(" ", "_")}
                    className="bg-(--pastel-gray) lg:p-4 p-6 rounded"
                    aria-label={title}
                >
                    <h4 className="lg:text-3xl text-2xl font-semibold">
                        {title}
                    </h4>
                    <p className="lg:py-3 pt-2">{description}</p>
                </article>
            ))}
        </div>

        <p className="text-(--old-lace) lg:text-xl lg:py-4 pt-6">
            These innovative therapies aim to create profound, lasting changes
            at a systemic level, supporting your body's natural healing
            processes and enhancing your mental state.
        </p>
    </section>
);

export default SystemicChangeTherapies;
