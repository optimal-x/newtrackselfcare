import PYSCHOTHERAPY_IMG from "../assets/page-3-rhs.webp";

const Psychotherapy = () => {
    return (
        <section
            id="psychotherapy"
            className="bg-[var(--old-lace)] px-4 py-5 md:px-15 lg:px-30 lg:py-10"
            aria-label="Psychotherapy services section"
        >
            <h3 className="text-center lg:text-left py-10 text-3xl lg:text-6xl text-[var(--kombu-green)] font-[Playfair]">
                Psychotherapy: Personalized Support
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <figure className="p-6 rounded-lg shadow sm:order-1">
                    <img
                        src={PYSCHOTHERAPY_IMG}
                        alt="Therapist's office with calming decor and natural light"
                        className="h-auto w-[400px] object-contain rounded-lg mx-auto"
                    />
                </figure>

                <article className="lg:p-6 rounded-lg lg:text-2xl sm:order-2">
                    <p>
                        Meet with our multidisciplinary team of experienced
                        therapists who specialize in a wide range of approaches.
                        We offer personalized psychotherapy tailored to your
                        unique needs, fostering a safe and confidential space
                        for growth and healing.
                    </p>
                    <p className="mt-4">
                        From cognitive behavioral therapy (CBT) to psychodynamic
                        approaches, our experts are here to guide you on your
                        journey toward mental clarity and emotional resilience.
                    </p>
                </article>
            </div>
        </section>
    );
};

export default Psychotherapy;