type AdvancedClinicalServicesProps = {
    number: number;
    title: string;
    content: string;
};

const boxes: AdvancedClinicalServicesProps[] = [
    {
        number: 1,
        title: "RTMS Therapy",
        content:
            "Repetitive Transcranial Magnetic Stimulation, a non-invasive treatment for depression.",
    },
    {
        number: 2,
        title: "IV Therapy",
        content:
            "Nutrient infusions to support your physical and mental health at a cellular level.",
    },
    {
        number: 3,
        title: "Holistic Nutrition",
        content:
            "Personalized dietary guidance to optimize brain function and overall well-being.",
    },
];

const ClinicalContentBox: React.FC<AdvancedClinicalServicesProps> = ({
    number,
    title,
    content,
}) => (
    <article
        className="lg:border border-(--pastel-gray) lg:p-2 p-4 rounded"
        aria-label={title}
    >
        <div className="hidden lg:block">
            <h3 className="text-center text-2xl lg:text-3xl font-[Lora] bg-(--eggshell) lg:p-2">
                {number}
            </h3>
        </div>
        <div className="lg:p-4">
            <h4 className="text-2xl lg:text-3xl font-[Lora] text-left text-center lg:text-left">
                <span className="lg:hidden">{number}. </span>
                {title}
            </h4>
            <p className="lg:text-lg lg:py-3 text-left">{content}</p>
        </div>
    </article>
);

const AdvancedClinicalServices: React.FC = () => (
    <section
        id="advanced-clinical-services"
        className="bg-(--old-lace) py-10 md:p-15 lg:p-30"
        aria-label="Advanced Clinical Services"
    >
        <h3 className="text-3xl text-(--kombu-green) text-center lg:text-left lg:text-6xl font-[Playfair] lg:py-5">
            Advanced Clinical Services
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-3 lg:gap-6">
            {boxes.map(({ number, title, content }) => (
                <ClinicalContentBox
                    key={title.toLowerCase().replaceAll(" ", "_")}
                    number={number}
                    title={title}
                    content={content}
                />
            ))}
        </div>
        <hr className="lg:hidden px-4 " />

        <p className="p-4 lg:p-0 lg:pt-5 lg:text-xl">
            These cutting-edge services are designed to address a wide range of
            conditions, offering targeted support for your health.
        </p>
    </section>
);

export default AdvancedClinicalServices;
