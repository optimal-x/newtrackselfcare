import PYSCHOTHERAPY_IMG from "../assets/page-9-lhs.webp";

const WorkshopAndGroupTherapy: React.FC = () => {
    return (
        <section
            id="workshops-and-group-therapy"
            className="bg-(--old-lace) p-4 md:px-15 md:py-5 lg:px-30 lg:py-10 p-4"
            aria-label="Workshops and Group Therapy"
        >
            <h3 className="text-center lg:text-left py-10 text-3xl lg:text-6xl text-[var(--kombu-green)] font-[Playfair]">
                Workshops & Group Therapy: Build Community
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 lg:gap-6">
                <figure className="p-6 rounded-lg shadow sm:order-1">
                    <img
                        src={PYSCHOTHERAPY_IMG}
                        alt="Group therapy session"
                        className="h-auto w-[400px] object-contain rounded-lg mx-auto"
                    />
                </figure>

                <article className="p-6 rounded-lg lg:text-2xl sm:order-2">
                    <p className="lg:pb-3">
                        Join our workshops and group therapy sessions to connect
                        with others who share similar experiences. These
                        sessions foster a supportive community built around what
                        truly matters: <strong>your well-being</strong>.
                    </p>
                    <p>
                        Explore topics from stress management to grief support
                        in an inclusive, empathetic space that encourages shared
                        learning and lasting growth.
                    </p>
                </article>
            </div>
        </section>
    );
};

export default WorkshopAndGroupTherapy;