import BRAIN_SVG from "../assets/neurology-24dp.svg";
import PLANT_SVG from "../assets/psychiatry-24dp.svg";

type ContentBoxesProps = {
    icon: string;
    title: string;
    content: string;
};

const PsychotherapyContentBoxes: React.FC<ContentBoxesProps> = ({
    icon,
    title,
    content,
}) => {
    return (
        <article
            className="relative p-6 lg:text-2xl shadow border-t-[10px] border-(--kombu-green) rounded-lg"
            aria-label={title}
        >
            <div className="absolute -top-7 left-1/2 -translate-x-1/2 w-15 h-15 bg-(--kombu-green) rounded-full flex items-center justify-center text-white shadow-md">
                <img src={icon} alt={`${title} icon`} className="w-8 h-8" />
            </div>
            <h4 className="text-4xl font-[Playfair] py-4 text-center">
                {title}
            </h4>
            <p className="lg:text-center">{content}</p>
        </article>
    );
};

const PsychedelicAssistedTherapy: React.FC = () => {
    return (
        <section
            id="psychedelic-assisted-therapy"
            className="bg-(--old-lace) md: py-5 md:px-15 lg:px-30 lg:py-10 p-4"
            aria-label="Psychedelic-Assisted Therapy section"
        >
            <h3 className="text-center py-20 text-3xl lg:text-6xl text-(--kombu-green) font-[Playfair]">
                Psychedelic-Assisted Therapy: A New Path to Healing
            </h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
                <PsychotherapyContentBoxes
                    icon={BRAIN_SVG}
                    title="Explore Potential"
                    content="Discover if psychedelic-assisted therapy could be a transformative option for your mental health journey. We offer a carefully guided and safe environment for this innovative approach."
                />
                <PsychotherapyContentBoxes
                    icon={PLANT_SVG}
                    title="Personalized Assessment"
                    content="Reach out to our team for a comprehensive assessment to determine if this unique therapy is the right fit for your specific needs and goals."
                />
            </div>

            <p className="lg:py-7 lg:text-xl lg:text-center lg:px-4 lg:px-20 py-8">
                This therapy is administered under strict medical supervision,
                emphasizing safety, integration, and a supportive therapeutic
                framework for profound insights and lasting change.
            </p>
        </section>
    );
};

export default PsychedelicAssistedTherapy;