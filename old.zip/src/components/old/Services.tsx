// components/CardGallery.tsx
type ServiceCard = {
    id: number;
    title: string;
    href: string;
};

const cards: Array<ServiceCard> = [
    { id: 1, title: "Psychotherapy", href: "psychotherapy" },
    {
        id: 2,
        title: "Psychedelic-Assisted Therapy",
        href: "psychedelic-assisted-therapy",
    },
    {
        id: 3,
        title: "Mindful Movement & Meditation",
        href: "mindful-movement-and-meditation",
    },
    { id: 4, title: "Holistic Body Work", href: "holistic-body-work" },
    {
        id: 5,
        title: "Advanced Clinical Services",
        href: "advanced-clinical-services",
    },
    {
        id: 6,
        title: "Systemic Change Therapies",
        href: "systemic-change-therapies",
    },
    {
        id: 7,
        title: "Workshops & Group Therapy",
        href: "workshops-and-group-therapy",
    },
];

const handleNavigation = (href: string) => {
    window.location.hash = `#${href}`;
};

const Services = () => (
    <div className="bg-(--old-lace) px-4 py-5 lg:px-30 lg:py-10 ">
        <section
            id="services"
            className="text-center justify-center"
            aria-labelledby="services-heading"
        >
            <h2
                id="services-heading"
                className="lg:p-10 text-5xl text-(--kombu-green) font-[Playfair] font-bold"
            >
                Our Services
            </h2>
        </section>

        <div className="w-full md:px-4 md:py-8 bg-(--old-lace)">
            <div className="flex flex-col md:flex-row md:flex-wrap md:justify-center gap-4">
                {cards.map((card) => (
                    <button
                        type="button"
                        key={card.id}
                        onClick={() => handleNavigation(card.href)}
                        className="h-50 w-full md:w-[calc(100%/3-1rem)] lg:w-[calc(100%/4-1rem)] xl:w-[calc(100%/7-1rem)] bg-(--old-lace) lg:p-4 flex flex-col text-center items-center justify-center hover:text-white hover:bg-(--kombu-green) rounded shadow-xl focus:outline-none focus:ring-2 focus:ring-(--kombu-green)"
                        aria-label={`Go to ${card.title} section`}
                    >
                        <h3 className="text-xl font-semibold">{card.title}</h3>
                    </button>
                ))}
            </div>
        </div>
    </div>
);

export default Services;
