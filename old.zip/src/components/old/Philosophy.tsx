import PHILOSOPHY_IMG from "../assets/page-2.webp";

const Philosophy = () => {
    return (
        <section
            id="philosophy"
            className="relative h-auto w-full bg-cover bg-fixed bg-center "
            style={{ backgroundImage: `url(${PHILOSOPHY_IMG})` }}
        >
            {/* Overlay */}
            <div className="absolute inset-0 bg-black/80 z-0"></div>

            {/* Content */}
            <div className="relative z-10 flex flex-col h-full text-(--old-lace)">
                <div className="px-4 py-7 md:px-15 lg:px-30">
                    <h2 className="text-2xl py-3 lg:text-4xl lg:py-20 font-[Playfair]">
                        Our Philosophy
                    </h2>
                    <h1 className="text-3xl py-1/8 lg:text-7xl lg:py-8 font-[Playfair]">
                        A Gym for the Mind, A Sanctuary for the Soul.
                    </h1>
                    <p className="py-7 lg:text-2xl lg:pb-25">
                        At NewTrack, we believe in nurturing both your mental
                        fortitude and inner tranquility. Our integrated approach
                        addresses your well-being holistically, providing tools
                        and support to navigate life's challenges and cultivate
                        lasting peace.
                    </p>
                </div>
            </div>
        </section>
    );
};

export default Philosophy;